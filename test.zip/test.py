import requests

api_url = 'https://api.api-ninjas.com/v1/jokes'
response = requests.get(api_url, headers={'X-Api-Key': 'J3sfX9WWNi2u5MIUo4eitA==upq3m9FpE8xoZRkD'})
if response.status_code == requests.codes.ok:
    print(response.text)
else:
    print("Error:", response.status_code, response.text)
